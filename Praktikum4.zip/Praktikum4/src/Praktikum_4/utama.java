package Praktikum_4;
import Praktikum_4.BangunDatar;

import java.util.Scanner;
class pilihan{
    public static void main (String [] args){
        {
            BangunDatar yudana = new BangunDatar();
            Scanner input = new Scanner(System.in);
            double a;
            System.out.println("Menghitung Luas dan Keliling Bangun Datar");
            System.out.println("1 => lingkaran \n2.=> segitiga\n3.=> persegi\n");
            System.out.println("Masukan pilihan = ");
            a = input.nextDouble();
            int masukan=0;
            if (a==1)
                yudana.lingkaran();
            else if (a==2)
                yudana.segitiga();
            else if (a==3)
                yudana.persegi();
            else
                System.out.println("pilihan salah");
        }}}